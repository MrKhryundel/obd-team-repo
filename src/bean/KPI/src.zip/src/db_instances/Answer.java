package db_instances;

public class Answer {
    public int AnswerID;
    public int ResponseID;
    public int QuestionID;
    public int OptionID;
    public String TextAnswer;
}
