package db_instances;

public class AnswerOption {
    public int OptionID;
    public int QuestionID;
    public String OptionText;
}
