package db_instances;

public class Question {
    public int QuestionID;
    public int FormID;
    public String Text;
    public String Type;
    public Boolean IsRequired;
}
