package db_instances;

import java.sql.Timestamp;

public class Form {
    public int FormID;
    public String Title;
    public int Description;
    public Timestamp CreatedAt;
    public int UserID;
}
