package db_instances;

public class User {
    public int UserId;
    public String Name;
    public String Email;
    public String CreatedAt;
    public String role;
}
