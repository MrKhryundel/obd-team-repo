package db_instances;

import java.sql.Timestamp;

public class Response {
    public int ResponseID;
    public int FormID;
    public Timestamp SubmittedAt;
}
